import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from auth import authenticate_user, register_user
from database import add_prediction, get_user_predictions, init_db

st.set_page_config(page_title="Diabetes Risk Prediction", page_icon="🩺", layout="wide")
init_db()

st.markdown("""
<style>
.main {background:#f5f8fc}
.hero {padding:22px;border-radius:14px;color:white;
background:linear-gradient(110deg,#173b63,#27849a);margin-bottom:15px}
div[data-testid="stMetric"] {background:white;padding:12px;border-radius:10px}
</style>""", unsafe_allow_html=True)

def risk_demo(age, glucose, bp, bmi):
    # Simulated educational score only; not a trained medical model.
    score = 0
    score += 40 if glucose >= 140 else 20 if glucose >= 100 else 0
    score += 25 if bmi >= 30 else 12 if bmi >= 25 else 0
    score += 15 if bp >= 90 else 0
    score += 15 if age >= 45 else 8 if age >= 35 else 0
    score = min(score, 95)
    label = "Higher educational risk" if score >= 50 else "Lower educational risk"
    return score, label

def login_screen():
    st.markdown('<div class="hero"><h1>🩺 Diabetes Risk Prediction</h1><p>Secure student project dashboard</p></div>', unsafe_allow_html=True)
    tab1, tab2 = st.tabs(["Login", "Sign Up"])
    with tab1:
        with st.form("login"):
            login = st.text_input("Username or email")
            password = st.text_input("Password", type="password")
            submit = st.form_submit_button("Login", use_container_width=True)
        if submit:
            user = authenticate_user(login, password)
            if user:
                st.session_state.user = user
                st.rerun()
            else:
                st.error("Incorrect login details.")
    with tab2:
        with st.form("signup"):
            username = st.text_input("Username")
            email = st.text_input("Email")
            password = st.text_input("Password (at least 8 characters)", type="password")
            confirm = st.text_input("Confirm password", type="password")
            submit = st.form_submit_button("Create account", use_container_width=True)
        if submit:
            if password != confirm:
                st.error("Passwords do not match.")
            else:
                ok, msg = register_user(username, email, password)
                (st.success if ok else st.error)(msg)
    st.caption("Passwords are stored as salted hashes in the local SQLite database.")

def main():
    if "user" not in st.session_state:
        login_screen()
        return
    user = st.session_state.user
    st.sidebar.title("🩺 Project Menu")
    st.sidebar.write("Signed in: " + user["username"])
    page = st.sidebar.radio("Navigate", ["Home Dashboard", "Risk Assessment", "History", "About Project"])
    if st.sidebar.button("Logout"):
        del st.session_state["user"]
        st.rerun()

    if page == "Home Dashboard":
        st.markdown(f'<div class="hero"><h1>Welcome, {user["username"]}</h1><p>Diabetes Risk Prediction System</p></div>', unsafe_allow_html=True)
        records = get_user_predictions(user["id"])
        st.metric("Your saved assessments", len(records))
        st.subheader("Sample data visualizations")
        rng = np.random.default_rng(42)
        sample = pd.DataFrame({"Glucose": np.clip(rng.normal(120, 28, 120), 65, 220),
                               "Category": rng.choice(["Lower risk", "Higher risk"], 120, p=[.68,.32])})
        left, right = st.columns(2)
        with left:
            fig, ax = plt.subplots()
            ax.hist(sample["Glucose"], bins=14)
            ax.set_title("Illustrative glucose distribution")
            ax.set_xlabel("Glucose (sample values)")
            st.pyplot(fig)
            plt.close(fig)
        with right:
            fig, ax = plt.subplots()
            sample["Category"].value_counts().plot(kind="bar", ax=ax)
            ax.set_title("Illustrative risk categories")
            st.pyplot(fig)
            plt.close(fig)
        st.info("Charts use generated sample data. This is an academic prototype, not a medical tool.")

    elif page == "Risk Assessment":
        st.title("Diabetes Risk Assessment")
        st.warning("Demonstration only: the score is simulated and is not a diagnosis.")
        with st.form("assessment"):
            c1, c2 = st.columns(2)
            with c1:
                age = st.number_input("Age", 18, 100, 30)
                glucose = st.number_input("Glucose value", 0.0, 300.0, 110.0)
            with c2:
                bp = st.number_input("Diastolic blood pressure", 0.0, 200.0, 75.0)
                bmi = st.number_input("BMI", 0.0, 80.0, 26.0)
            submit = st.form_submit_button("Calculate demo result")
        if submit:
            score, label = risk_demo(age, glucose, bp, bmi)
            add_prediction(user["id"], age, glucose, bp, bmi, label, score)
            st.session_state.result = (score, label)
        if "result" in st.session_state:
            score, label = st.session_state.result
            st.metric("Illustrative score", f"{score}/95")
            st.progress(score / 95)
            st.success(label)

    elif page == "History":
        st.title("Assessment History")
        records = get_user_predictions(user["id"])
        if records:
            frame = pd.DataFrame(records)
            st.dataframe(frame, use_container_width=True, hide_index=True)
            st.download_button("Download history CSV", frame.to_csv(index=False),
                               "assessment_history.csv", "text/csv")
        else:
            st.info("No assessments saved yet.")

    else:
        st.title("About This Project")
        st.write("This is the initial Streamlit dashboard for a diabetes-related classification project.")
        st.write("Selected public dataset for future EDA and model training: Pima Indians Diabetes Database.")
        st.markdown("[Kaggle dataset page](https://www.kaggle.com/datasets/uciml/pima-indians-diabetes-database)")
        st.write("Model training is not included at this assignment stage, as the instructions say it is not required yet.")
        st.caption("The current simulated score is not trained or clinically validated.")

    st.sidebar.caption("Academic prototype • Not for medical decisions")

if __name__ == "__main__":
    main()
