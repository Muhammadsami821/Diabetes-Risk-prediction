import hashlib
import hmac
import re
import secrets
from database import get_connection

ITERATIONS = 260_000

def hash_password(password, salt_hex):
    salt = bytes.fromhex(salt_hex)
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, ITERATIONS).hex()

def validate_registration(username, email, password):
    if len(username.strip()) < 3:
        return False, "Username must contain at least 3 characters."
    if not re.fullmatch(r"[^@\\s]+@[^@\\s]+\\.[^@\\s]+", email.strip()):
        return False, "Enter a valid email address."
    if len(password) < 8:
        return False, "Password must contain at least 8 characters."
    return True, "Valid"

def register_user(username, email, password):
    valid, message = validate_registration(username, email, password)
    if not valid:
        return False, message
    salt = secrets.token_hex(16)
    hashed = hash_password(password, salt)
    try:
        with get_connection() as conn:
            conn.execute("INSERT INTO users(username,email,password_hash,salt) VALUES(?,?,?,?)",
                         (username.strip(), email.strip().lower(), hashed, salt))
            conn.commit()
        return True, "Account created. You can now log in."
    except Exception as exc:
        if "UNIQUE constraint failed" in str(exc):
            return False, "Username or email is already registered."
        return False, "Could not create account. Please try again."

def authenticate_user(login, password):
    with get_connection() as conn:
        user = conn.execute("""SELECT id,username,email,password_hash,salt
            FROM users WHERE username=? OR email=?""",
            (login.strip(), login.strip().lower())).fetchone()
    if user is None:
        return None
    if hmac.compare_digest(hash_password(password, user["salt"]), user["password_hash"]):
        return {"id": user["id"], "username": user["username"], "email": user["email"]}
    return None
