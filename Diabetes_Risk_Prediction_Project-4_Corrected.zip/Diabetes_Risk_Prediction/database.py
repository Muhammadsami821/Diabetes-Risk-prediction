import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent / "diabetes_app.db"

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_connection() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            salt TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            age INTEGER NOT NULL,
            glucose REAL NOT NULL,
            blood_pressure REAL NOT NULL,
            bmi REAL NOT NULL,
            risk_label TEXT NOT NULL,
            risk_score INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )""")
        conn.commit()

def add_prediction(user_id, age, glucose, blood_pressure, bmi, label, score):
    with get_connection() as conn:
        conn.execute("""INSERT INTO predictions
            (user_id, age, glucose, blood_pressure, bmi, risk_label, risk_score)
            VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (user_id, age, glucose, blood_pressure, bmi, label, score))
        conn.commit()

def get_user_predictions(user_id):
    with get_connection() as conn:
        rows = conn.execute("""SELECT age, glucose, blood_pressure, bmi,
            risk_label, risk_score, created_at FROM predictions
            WHERE user_id=? ORDER BY id DESC""", (user_id,)).fetchall()
    return [dict(row) for row in rows]
