Selected dataset: Pima Indians Diabetes Database.
Download: https://www.kaggle.com/datasets/uciml/pima-indians-diabetes-database
Place the downloaded diabetes.csv file in this folder for future EDA/model training. The current assignment stage does not require model training.
