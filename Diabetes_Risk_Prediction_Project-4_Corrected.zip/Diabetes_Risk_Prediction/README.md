# Diabetes Risk Prediction System

**Student:** Muhammad Sami  
**MIS ID:** 48035  
**Project:** AI Programming — Initial Streamlit Dashboard

## Objective
Develop an interactive dashboard for a diabetes-related classification project with database-integrated user authentication.

## Assignment scope implemented
- Streamlit dashboard with navigation, forms, charts and sample outputs
- Separate signup and login with input validation
- SQLite database for user accounts and assessment history
- Salted PBKDF2-HMAC-SHA256 password hashing (no plain-text passwords)
- Virtual environment setup instructions
- requirements.txt and organized Python source files
- .gitignore to exclude local database, secrets and virtual environment
- Public dataset selected for future EDA/model training

## Dataset selected
Pima Indians Diabetes Database: https://www.kaggle.com/datasets/uciml/pima-indians-diabetes-database  
Download `diabetes.csv` and place it in `data/` for future EDA. The current prototype does not train a model.

## Requirements
Python 3.10+, VS Code, internet for package installation.

## Install on Windows
Open the project folder in VS Code, then Terminal > New Terminal:

```bash
python -m venv venv
venv\\Scripts\\activate
pip install -r requirements.txt
```

## Run
```bash
streamlit run app.py
```

Create an account in the Sign Up tab, then log in.

## Files
- `app.py`: Streamlit dashboard and sample risk interface
- `auth.py`: signup, login, validation and password hashing
- `database.py`: SQLite database operations
- `requirements.txt`: Python dependencies
- `.gitignore`: excludes local/private files
- `data/README.md`: dataset instructions

## GitHub
Create a public repository named `Diabetes-Risk-Prediction-System`, then upload project source files. Do not upload `venv/`, `.env`, `diabetes_app.db`, passwords, or real user records. Copy the public repository URL after uploading and submit that link.

## Health notice
The risk result is a simple simulated demonstration score, not a trained or clinically validated model. This project is for academic demonstration only and must not be used for diagnosis or treatment.
